"use client"

import { useState } from "react"
import { ApiProvider } from "@/contexts/api-context"
import { ThemeProvider } from "@/components/theme-provider"
import { Sidebar } from "@/components/layout/sidebar"
import { RequestBuilder } from "@/components/request/request-builder"
import { ResponseViewer } from "@/components/response/response-viewer"
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable"
import { Button } from "@/components/ui/button"
import { PanelLeftClose, PanelLeftOpen } from "lucide-react"

export default function Component() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <ApiProvider>
        <div className="h-screen flex">
          {/* Collapsible Sidebar */}
          <div className={`transition-all duration-300 ${sidebarCollapsed ? "w-0" : "w-80"} overflow-hidden`}>
            <Sidebar />
          </div>

          {/* Sidebar Toggle Button */}
          <div className="flex flex-col border-r">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="h-10 w-10 p-0 border-b rounded-none"
              title={sidebarCollapsed ? "Show sidebar (Ctrl+B)" : "Hide sidebar (Ctrl+B)"}
            >
              {sidebarCollapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
            </Button>
          </div>

          {/* Main Content Area with Resizable Panels */}
          <div className="flex-1">
            <ResizablePanelGroup direction="horizontal">
              <ResizablePanel defaultSize={50} minSize={30} maxSize={70}>
                <RequestBuilder />
              </ResizablePanel>

              <ResizableHandle withHandle />

              <ResizablePanel defaultSize={50} minSize={30} maxSize={70}>
                <ResponseViewer />
              </ResizablePanel>
            </ResizablePanelGroup>
          </div>
        </div>
      </ApiProvider>
    </ThemeProvider>
  )
}
