#!/bin/bash

# Build script for all platforms

echo "Building REST API Client for all platforms..."

# Install dependencies
npm install

# Build Next.js app
npm run build

# Build for all platforms
echo "Building for Windows..."
npm run dist-win

echo "Building for macOS..."
npm run dist-mac

echo "Building for Linux..."
npm run dist-linux

echo "Build complete! Check the dist/ folder for installers."
