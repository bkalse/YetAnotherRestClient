# PowerShell build script for Windows

Write-Host "Building REST API Client for all platforms..." -ForegroundColor Green

# Install dependencies
npm install

# Build Next.js app
npm run build

# Build for all platforms
Write-Host "Building for Windows..." -ForegroundColor Yellow
npm run dist-win

Write-Host "Building for macOS..." -ForegroundColor Yellow
npm run dist-mac

Write-Host "Building for Linux..." -ForegroundColor Yellow
npm run dist-linux

Write-Host "Build complete! Check the dist/ folder for installers." -ForegroundColor Green
