import { type NextRequest, NextResponse } from "next/server"

// Mock data - in a real app, this would come from a database
const properties = [
  {
    id: "p1",
    userId: "1",
    address: "123 Main St, New York, NY",
    type: "Apartment",
    price: 450000,
    bedrooms: 2,
    bathrooms: 1,
  },
  {
    id: "p2",
    userId: "1",
    address: "456 Oak Ave, Brooklyn, NY",
    type: "House",
    price: 750000,
    bedrooms: 3,
    bathrooms: 2,
  },
  {
    id: "p3",
    userId: "2",
    address: "789 Pine St, Queens, NY",
    type: "Condo",
    price: 320000,
    bedrooms: 1,
    bathrooms: 1,
  },
]

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  const propertyData = await request.json()
  const propertyIndex = properties.findIndex((property) => property.id === params.id)

  if (propertyIndex === -1) {
    return NextResponse.json({ error: "Property not found" }, { status: 404 })
  }

  properties[propertyIndex] = { ...properties[propertyIndex], ...propertyData }
  return NextResponse.json(properties[propertyIndex])
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const propertyIndex = properties.findIndex((property) => property.id === params.id)

  if (propertyIndex === -1) {
    return NextResponse.json({ error: "Property not found" }, { status: 404 })
  }

  properties.splice(propertyIndex, 1)
  return NextResponse.json({ message: "Property deleted successfully" })
}
