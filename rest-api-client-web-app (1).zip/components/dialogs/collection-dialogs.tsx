"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { AlertTriangle, Trash2, Edit3 } from "lucide-react"
import type { Collection } from "@/lib/types/api"

interface RenameCollectionDialogProps {
  collection: Collection | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onRename: (id: string, newName: string) => void
}

export function RenameCollectionDialog({ collection, open, onOpenChange, onRename }: RenameCollectionDialogProps) {
  const [newName, setNewName] = useState(collection?.name || "")

  const handleRename = () => {
    if (collection && newName.trim()) {
      onRename(collection.id, newName.trim())
      onOpenChange(false)
    }
  }

  const handleOpenChange = (isOpen: boolean) => {
    if (isOpen && collection) {
      setNewName(collection.name)
    }
    onOpenChange(isOpen)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Edit3 className="w-5 h-5" />
            Rename Collection
          </DialogTitle>
          <DialogDescription>
            Enter a new name for "{collection?.name}". This will update the collection name.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="collection-name" className="text-right">
              Name
            </Label>
            <Input
              id="collection-name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="col-span-3"
              placeholder="Enter collection name"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleRename()
                }
              }}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleRename} disabled={!newName.trim() || newName.trim() === collection?.name}>
            Rename Collection
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

interface DeleteCollectionDialogProps {
  collection: Collection | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onDelete: (id: string) => void
}

export function DeleteCollectionDialog({ collection, open, onOpenChange, onDelete }: DeleteCollectionDialogProps) {
  const [isDeleting, setIsDeleting] = useState(false)

  const handleDelete = async () => {
    if (collection) {
      setIsDeleting(true)
      // Add a small delay to show the loading state
      await new Promise((resolve) => setTimeout(resolve, 500))
      onDelete(collection.id)
      setIsDeleting(false)
      onOpenChange(false)
    }
  }

  const requestCount = collection?.requests?.length || 0
  const hasRequests = requestCount > 0

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="w-5 h-5" />
            Delete Collection
          </DialogTitle>
          <DialogDescription className="text-left">
            Are you sure you want to delete "{collection?.name}"?
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {hasRequests && (
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4 mb-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-yellow-800 dark:text-yellow-200 mb-1">Data Loss Warning</h4>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300">
                    This collection contains{" "}
                    <strong>
                      {requestCount} request{requestCount !== 1 ? "s" : ""}
                    </strong>
                    . Deleting this collection will move it to trash, but you can restore it later if needed.
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="bg-muted/50 rounded-lg p-4">
            <h4 className="font-medium mb-2">What happens when you delete:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Collection will be moved to trash (soft delete)</li>
              <li>• All requests in this collection will be preserved</li>
              <li>• You can restore the collection later if needed</li>
              <li>• No data is permanently lost</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={handleDelete} disabled={isDeleting} className="gap-2">
            <Trash2 className="w-4 h-4" />
            {isDeleting ? "Deleting..." : "Delete Collection"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
