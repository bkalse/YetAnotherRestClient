"use client"

import type React from "react"
import { createContext, useContext, useReducer, useEffect } from "react"
import type { Collection, RequestConfig, RequestHistory, Environment, ApiResponse } from "@/lib/types/api"
import { StorageManager } from "@/lib/utils/storage"
import { ApiClient } from "@/lib/utils/api-client"

interface ApiState {
  collections: Collection[]
  currentRequest: RequestConfig | null
  history: RequestHistory[]
  environments: Environment[]
  activeEnvironment: Environment | null
  isLoading: boolean
  response: ApiResponse | null
}

type ApiAction =
  | { type: "SET_COLLECTIONS"; payload: Collection[] }
  | { type: "ADD_COLLECTION"; payload: Collection }
  | { type: "UPDATE_COLLECTION"; payload: Collection }
  | { type: "DELETE_COLLECTION"; payload: string }
  | { type: "RENAME_COLLECTION"; payload: { id: string; name: string } } // Add rename action
  | { type: "SOFT_DELETE_COLLECTION"; payload: string } // Add soft delete action
  | { type: "RESTORE_COLLECTION"; payload: string } // Add restore action
  | { type: "SET_CURRENT_REQUEST"; payload: RequestConfig | null }
  | { type: "UPDATE_CURRENT_REQUEST"; payload: Partial<RequestConfig> }
  | { type: "ADD_REQUEST_TO_COLLECTION"; payload: { collectionId: string; request: RequestConfig } }
  | { type: "SET_HISTORY"; payload: RequestHistory[] }
  | { type: "ADD_TO_HISTORY"; payload: RequestHistory }
  | { type: "SET_ENVIRONMENTS"; payload: Environment[] }
  | { type: "SET_ACTIVE_ENVIRONMENT"; payload: Environment | null }
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_RESPONSE"; payload: ApiResponse | null }

const initialState: ApiState = {
  collections: [],
  currentRequest: null,
  history: [],
  environments: [],
  activeEnvironment: null,
  isLoading: false,
  response: null,
}

function apiReducer(state: ApiState, action: ApiAction): ApiState {
  switch (action.type) {
    case "SET_COLLECTIONS":
      return { ...state, collections: action.payload }

    case "ADD_COLLECTION":
      return { ...state, collections: [...state.collections, action.payload] }

    case "UPDATE_COLLECTION":
      return {
        ...state,
        collections: state.collections.map((c) => (c.id === action.payload.id ? action.payload : c)),
      }

    case "DELETE_COLLECTION":
      return {
        ...state,
        collections: state.collections.filter((c) => c.id !== action.payload),
      }

    case "RENAME_COLLECTION":
      return {
        ...state,
        collections: state.collections.map((c) =>
          c.id === action.payload.id ? { ...c, name: action.payload.name, updatedAt: new Date().toISOString() } : c,
        ),
      }

    case "SOFT_DELETE_COLLECTION":
      return {
        ...state,
        collections: state.collections.map((c) =>
          c.id === action.payload ? { ...c, deleted: true, updatedAt: new Date().toISOString() } : c,
        ),
      }

    case "RESTORE_COLLECTION":
      return {
        ...state,
        collections: state.collections.map((c) =>
          c.id === action.payload ? { ...c, deleted: false, updatedAt: new Date().toISOString() } : c,
        ),
      }

    case "SET_CURRENT_REQUEST":
      return { ...state, currentRequest: action.payload }

    case "UPDATE_CURRENT_REQUEST":
      return {
        ...state,
        currentRequest: state.currentRequest ? { ...state.currentRequest, ...action.payload } : null,
      }

    case "ADD_REQUEST_TO_COLLECTION":
      return {
        ...state,
        collections: state.collections.map((c) =>
          c.id === action.payload.collectionId ? { ...c, requests: [...c.requests, action.payload.request] } : c,
        ),
      }

    case "SET_HISTORY":
      return { ...state, history: action.payload }

    case "ADD_TO_HISTORY":
      return { ...state, history: [action.payload, ...state.history] }

    case "SET_ENVIRONMENTS":
      return { ...state, environments: action.payload }

    case "SET_ACTIVE_ENVIRONMENT":
      return { ...state, activeEnvironment: action.payload }

    case "SET_LOADING":
      return { ...state, isLoading: action.payload }

    case "SET_RESPONSE":
      return { ...state, response: action.payload }

    default:
      return state
  }
}

const ApiContext = createContext<{
  state: ApiState
  dispatch: React.Dispatch<ApiAction>
  sendRequest: () => Promise<void>
  createDefaultRequest: () => RequestConfig
  handleElectronImport: (filePath: string) => Promise<void>
  handleElectronExport: (filePath: string) => Promise<void>
} | null>(null)

export function ApiProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(apiReducer, initialState)

  // Load data from localStorage on mount
  useEffect(() => {
    const collections = StorageManager.getCollections()
    const history = StorageManager.getHistory()
    const environments = StorageManager.getEnvironments()
    const activeEnvId = StorageManager.getActiveEnvironment()

    dispatch({ type: "SET_COLLECTIONS", payload: collections })
    dispatch({ type: "SET_HISTORY", payload: history })
    dispatch({ type: "SET_ENVIRONMENTS", payload: environments })

    if (activeEnvId) {
      const activeEnv = environments.find((e) => e.id === activeEnvId)
      if (activeEnv) {
        dispatch({ type: "SET_ACTIVE_ENVIRONMENT", payload: activeEnv })
      }
    }
  }, [])

  const createDefaultRequest = (): RequestConfig => ({
    id: crypto.randomUUID(),
    name: "New Request",
    method: "GET",
    url: "",
    headers: [],
    body: {
      type: "none",
      content: "",
    },
    auth: {
      type: "none",
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  })

  const sendRequest = async () => {
    if (!state.currentRequest) return

    dispatch({ type: "SET_LOADING", payload: true })
    dispatch({ type: "SET_RESPONSE", payload: null })

    try {
      const response = await ApiClient.sendRequest(state.currentRequest, state.activeEnvironment || undefined)

      dispatch({ type: "SET_RESPONSE", payload: response })

      // Add to history
      const historyItem: RequestHistory = {
        id: crypto.randomUUID(),
        request: { ...state.currentRequest },
        response,
        timestamp: new Date().toISOString(),
      }

      dispatch({ type: "ADD_TO_HISTORY", payload: historyItem })
    } catch (error) {
      dispatch({ type: "SET_RESPONSE", payload: error as ApiResponse })
    } finally {
      dispatch({ type: "SET_LOADING", payload: false })
    }
  }

  const handleElectronImport = async (filePath: string) => {
    if (window.electronAPI) {
      try {
        const result = await window.electronAPI.readFile(filePath)
        if (result.success && result.data) {
          const data = JSON.parse(result.data)
          if (StorageManager.importData(data)) {
            // Reload data
            const collections = StorageManager.getCollections()
            const history = StorageManager.getHistory()
            const environments = StorageManager.getEnvironments()

            dispatch({ type: "SET_COLLECTIONS", payload: collections })
            dispatch({ type: "SET_HISTORY", payload: history })
            dispatch({ type: "SET_ENVIRONMENTS", payload: environments })
          }
        }
      } catch (error) {
        console.error("Error importing data:", error)
      }
    }
  }

  const handleElectronExport = async (filePath: string) => {
    if (window.electronAPI) {
      try {
        const data = StorageManager.exportData()
        const result = await window.electronAPI.writeFile(filePath, JSON.stringify(data, null, 2))
        if (!result.success) {
          console.error("Error exporting data:", result.error)
        }
      } catch (error) {
        console.error("Error exporting data:", error)
      }
    }
  }

  return (
    <ApiContext.Provider
      value={{
        state,
        dispatch,
        sendRequest,
        createDefaultRequest,
        handleElectronImport,
        handleElectronExport,
      }}
    >
      {children}
    </ApiContext.Provider>
  )
}

export function useApi() {
  const context = useContext(ApiContext)
  if (!context) {
    throw new Error("useApi must be used within an ApiProvider")
  }
  return context
}
