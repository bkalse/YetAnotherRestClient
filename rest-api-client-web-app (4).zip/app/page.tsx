import Component from "./app"

export default function Page() {
  return <Component />
}
