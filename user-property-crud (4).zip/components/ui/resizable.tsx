"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

interface ResizablePanelGroupProps extends React.HTMLAttributes<HTMLDivElement> {
  direction?: "horizontal" | "vertical"
}

interface ResizablePanelProps extends React.HTMLAttributes<HTMLDivElement> {
  defaultSize?: number
  minSize?: number
  maxSize?: number
}

interface ResizableHandleProps extends React.HTMLAttributes<HTMLDivElement> {
  withHandle?: boolean
}

const ResizablePanelGroup = React.forwardRef<HTMLDivElement, ResizablePanelGroupProps>(
  ({ className, direction = "horizontal", children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "flex h-full w-full data-[panel-group]:overflow-hidden",
          direction === "horizontal" ? "flex-row" : "flex-col",
          className,
        )}
        data-panel-group=""
        {...props}
      >
        {children}
      </div>
    )
  },
)
ResizablePanelGroup.displayName = "ResizablePanelGroup"

const ResizablePanel = React.forwardRef<HTMLDivElement, ResizablePanelProps>(
  ({ className, defaultSize, minSize, maxSize, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn("relative flex-1", className)}
        data-panel=""
        style={{
          flexBasis: defaultSize ? `${defaultSize}%` : undefined,
          minWidth: minSize ? `${minSize}%` : undefined,
          maxWidth: maxSize ? `${maxSize}%` : undefined,
        }}
        {...props}
      >
        {children}
      </div>
    )
  },
)
ResizablePanel.displayName = "ResizablePanel"

const ResizableHandle = React.forwardRef<HTMLDivElement, ResizableHandleProps>(
  ({ className, withHandle = false, ...props }, ref) => {
    const [isDragging, setIsDragging] = React.useState(false)
    const [startX, setStartX] = React.useState(0)
    const [startWidths, setStartWidths] = React.useState<number[]>([])

    const handleMouseDown = (e: React.MouseEvent) => {
      setIsDragging(true)
      setStartX(e.clientX)

      const panelGroup = (e.target as HTMLElement).closest("[data-panel-group]")
      if (panelGroup) {
        const panels = Array.from(panelGroup.querySelectorAll("[data-panel]")) as HTMLElement[]
        const widths = panels.map((panel) => panel.offsetWidth)
        setStartWidths(widths)
      }
    }

    React.useEffect(() => {
      const handleMouseMove = (e: MouseEvent) => {
        if (!isDragging) return

        const handle = document.querySelector("[data-panel-resize-handle]") as HTMLElement
        if (!handle) return

        const panelGroup = handle.closest("[data-panel-group]") as HTMLElement
        if (!panelGroup) return

        const panels = Array.from(panelGroup.querySelectorAll("[data-panel]")) as HTMLElement[]
        if (panels.length !== 2) return

        const deltaX = e.clientX - startX
        const groupWidth = panelGroup.offsetWidth
        const deltaPercent = (deltaX / groupWidth) * 100

        const leftPanel = panels[0]
        const rightPanel = panels[1]

        const leftWidth = Math.max(20, Math.min(80, (startWidths[0] / groupWidth) * 100 + deltaPercent))
        const rightWidth = 100 - leftWidth

        leftPanel.style.flexBasis = `${leftWidth}%`
        rightPanel.style.flexBasis = `${rightWidth}%`
      }

      const handleMouseUp = () => {
        setIsDragging(false)
      }

      if (isDragging) {
        document.addEventListener("mousemove", handleMouseMove)
        document.addEventListener("mouseup", handleMouseUp)
      }

      return () => {
        document.removeEventListener("mousemove", handleMouseMove)
        document.removeEventListener("mouseup", handleMouseUp)
      }
    }, [isDragging, startX, startWidths])

    return (
      <div
        ref={ref}
        className={cn(
          "relative flex w-px items-center justify-center bg-border after:absolute after:inset-y-0 after:left-1/2 after:w-1 after:-translate-x-1/2 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 data-[panel-group-direction=vertical]:h-px data-[panel-group-direction=vertical]:w-full data-[panel-group-direction=vertical]:after:left-0 data-[panel-group-direction=vertical]:after:h-1 data-[panel-group-direction=vertical]:after:w-full data-[panel-group-direction=vertical]:after:-translate-y-1/2 data-[panel-group-direction=vertical]:after:translate-x-0 [&[data-panel-group-direction=vertical]>div]:rotate-90",
          isDragging && "bg-primary",
          className,
        )}
        data-panel-resize-handle=""
        onMouseDown={handleMouseDown}
        style={{ cursor: "col-resize" }}
        {...props}
      >
        {withHandle && (
          <div className="z-10 flex h-4 w-3 items-center justify-center rounded-sm border bg-border">
            <div className="h-2.5 w-[3px] rounded-[1px] bg-foreground/25" />
          </div>
        )}
      </div>
    )
  },
)
ResizableHandle.displayName = "ResizableHandle"

export { ResizablePanelGroup, ResizablePanel, ResizableHandle }
