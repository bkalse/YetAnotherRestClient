import { type NextRequest, NextResponse } from "next/server"

// Mock data - in a real app, this would come from a database
const users = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "+1 (555) 987-6543",
  },
]

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const userData = await request.json()
  const userIndex = users.findIndex((user) => user.id === params.id)

  if (userIndex === -1) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  users[userIndex] = { ...users[userIndex], ...userData }
  return NextResponse.json(users[userIndex])
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const userIndex = users.findIndex((user) => user.id === params.id)

  if (userIndex === -1) {
    return NextResponse.json({ error: "User not found" }, { status: 404 })
  }

  users.splice(userIndex, 1)
  return NextResponse.json({ message: "User deleted successfully" })
}
