import { type NextRequest, NextResponse } from "next/server"

// Mock data - in a real app, this would come from a database
const users = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "+1 (555) 987-6543",
  },
]

export async function GET() {
  return NextResponse.json(users)
}

export async function POST(request: NextRequest) {
  const userData = await request.json()
  const newUser = {
    ...userData,
    id: Date.now().toString(),
  }
  users.push(newUser)
  return NextResponse.json(newUser, { status: 201 })
}
