#!/bin/bash

# Build script for all platforms

echo "🚀 Building REST API Client for all platforms..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Create icon placeholders
echo "🎨 Creating icon placeholders..."
node electron/assets/create-icons.js

# Build Next.js app
echo "🔨 Building Next.js app..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Failed to build Next.js app"
    exit 1
fi

# Build for all platforms
echo "📱 Building for Windows..."
npm run dist-win

echo "🍎 Building for macOS..."
npm run dist-mac

echo "🐧 Building for Linux..."
npm run dist-linux

echo "✅ Build complete! Check the dist/ folder for installers."
echo "📁 Distribution files:"
ls -la dist/ 2>/dev/null || echo "No dist folder found - check for build errors above"
