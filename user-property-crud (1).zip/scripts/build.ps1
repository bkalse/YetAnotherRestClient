# PowerShell build script for Windows

Write-Host "🚀 Building REST API Client for all platforms..." -ForegroundColor Green

# Check if Node.js is installed
try {
    $nodeVersion = node --version
    Write-Host "✅ Node.js version: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js is not installed. Please install Node.js first." -ForegroundColor Red
    exit 1
}

# Check if npm is installed
try {
    $npmVersion = npm --version
    Write-Host "✅ npm version: $npmVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ npm is not installed. Please install npm first." -ForegroundColor Red
    exit 1
}

# Install dependencies
Write-Host "📦 Installing dependencies..." -ForegroundColor Yellow
npm install

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Failed to install dependencies" -ForegroundColor Red
    exit 1
}

# Create icon placeholders
Write-Host "🎨 Creating icon placeholders..." -ForegroundColor Yellow
node electron/assets/create-icons.js

# Build Next.js app
Write-Host "🔨 Building Next.js app..." -ForegroundColor Yellow
npm run build

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Failed to build Next.js app" -ForegroundColor Red
    exit 1
}

# Build for all platforms
Write-Host "📱 Building for Windows..." -ForegroundColor Yellow
npm run dist-win

Write-Host "🍎 Building for macOS..." -ForegroundColor Yellow
npm run dist-mac

Write-Host "🐧 Building for Linux..." -ForegroundColor Yellow
npm run dist-linux

Write-Host "✅ Build complete! Check the dist/ folder for installers." -ForegroundColor Green

# List distribution files
if (Test-Path "dist") {
    Write-Host "📁 Distribution files:" -ForegroundColor Cyan
    Get-ChildItem dist | Format-Table Name, Length, LastWriteTime
} else {
    Write-Host "No dist folder found - check for build errors above" -ForegroundColor Yellow
}
